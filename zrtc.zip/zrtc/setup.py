#coding:utf-8
__author__ = 'aron'

from setuptools import setup, find_packages

setup(
      name="zrtc",
      version="0.1",
      description="Zero Real Mesage control ",
      author="llc_xyz@zhuc.net",
      url="http://www.xunjiexidi.com",
      license="XUNJIEXIDI",
      packages=find_packages(),
    )
