# coding:utf-8
import zmq
__author__ = 'Aron'
import logging
import os

import json
import threading

log = logging.getLogger("zrtc.pub")


class publisher(threading.Thread):

    def __init__(self, mode='node', target="tcp://127.0.0.1:8002"):
        threading.Thread.__init__(self, name="pub")
        self.target = target
        self.mode = mode
        self.pub_socket = self.create_pub_socket(self.target, mode)
        self.pub({'pid': os.getpid(), "type": 'init', 'data': 'pub socket created'})
    
    def create_pub_socket(self, target="tcp://127.0.0.1:8002", mode='node'):
        context = zmq.Context()
        pub_socket = context.socket(zmq.PUB)
        if mode == 'node':
            pub_socket.connect(target)
        elif mode == 'master':
            pub_socket.bind(target)

        log.info("pid[%s] create pub socket(mode=%s) on target %s ok!" % (os.getpid(), mode, target))
        return pub_socket

    def pub(self, msg):
        if self.pub_socket:
            self.pub_socket.send_json(msg)

    def pub_topic(self, topic, data):
        self.pub_socket.send_string("%s:%s" % (topic, json.dumps(data)))




