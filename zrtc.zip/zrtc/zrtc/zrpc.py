# coding:utf-8
import errno
import zmq
__author__ = 'Aron'
import logging
import os

import traceback
import sys
import werkzeug
import tempfile
from Crypto.Cipher import AES
from hashlib import md5

import base64
import threading
import thread
import uuid
import zlib
from zmq.utils import  jsonapi
import pickle
import logging

format = '%(asctime)-15s %(levelname)s %(module)s  %(message)s'
logging.basicConfig(format=format, level=logging.DEBUG)

log = logging.getLogger("zrpc")

ERR_CODE_AUTH_REQUIRED = -1002
ERR_CODE_AUTH_FAILED = -1000

class AESCypher(object):
    def __init__(self, secret=None, block_size=16, padding='$'):
        # block_size = 16 -> 128bits
        self.block_size = block_size
        self.padding = padding
        self.secret = secret or os.urandom(self.block_size)

    def add_padding(self, val):
        bsize, padding = self.block_size, self.padding
        return val + (bsize - len(val) % bsize) * padding

    def encode_aes(self, cipher, value):
        return base64.b64encode(zlib.compress(cipher.encrypt(self.add_padding(value))))

    def decode_aes(self, chipher, value):
        return chipher.decrypt(zlib.decompress(base64.b64decode(value))).rstrip(self.padding)

    def encrypt(self, private_info):
        return self.encode_aes(AES.new(self.secret), private_info)

    def decrypt(self, value):
        return self.decode_aes(AES.new(self.secret), value)


class zrpcException(Exception):
    def __init__(self, code, msg):
        Exception.__init__(self, code, msg)
        self.code = code
        self.message = msg

class zrpcAuthFailed(zrpcException):
    pass


class zrpcClient(threading.Thread):
    def __init__(self, target="tcp://127.0.0.1:8100", encrypt_mode=True, read_timeout=5000, write_timeout=5000):
        threading.Thread.__init__(self, name="zrpc-client")
        self.user_session_pair = {}
        self.encrypt_mode = encrypt_mode
        self.read_timeout = read_timeout
        self.write_timeout = write_timeout
        self.target = target
        self.req_socket = False
        self.aes_key = False
        self.aes_cyhper = False
        self.users = {}

        self.init_sock()

    def init_sock(self):
        self.req_socket = self.create_req_socket(target=self.target)

    def run(self):
        pass

    def create_req_socket(self, target="tcp://127.0.0.1:8100"):
        context = zmq.Context()
        push_socket = context.socket(zmq.REQ)
        push_socket.setsockopt(zmq.RCVTIMEO, self.read_timeout)  # 5秒接收超时.
        push_socket.setsockopt(zmq.SNDTIMEO, self.write_timeout)   # 5秒发送超时.
        push_socket.connect(target)
        log.info("pid[%s] create req socket to target %s ok!" %(os.getpid(), target))
        return push_socket

    def req(self, session, msg):
        if session in self.user_session_pair:
            return self._req(session, msg)
        else:
            raise zrpcException(-5, "Please Auth first!")

    def req_no_auth(self, msg):
        return self._req("", msg)

    def get_identify(self, domain, username):
        return "%s@%s" % (username, domain)

    def auth(self, domain, username, password):
        d = self._build_auth_request(domain, username, password)

        self._send(d)
        msg = self._recv()

        if msg['r'] == 0:
            session = msg['s']
            aes_cyhper = AESCypher(secret=msg['a'])
            identify = self.get_identify(domain, username)
            self.user_session_pair[identify] = [session, aes_cyhper]
            if domain not in self.users:
                self.users[domain] = {username: password}

            return identify

        else:
            raise zrpcAuthFailed(-1000, " Auth Failed(%s)" % msg['m'])

    def _build_auth_request(self, domain, username, password):
        d = {'e': self.encrypt_mode}
        d.update({'a': '%s\n%s\n%s' % (domain, username, md5(password).hexdigest())})
        return d

    def _build_request(self, identify,  body, encrypt):
        d = {}
        if identify in self.user_session_pair:
                d.update({'s': self.user_session_pair[identify][0]})

        if encrypt:
            body = self._encode(identify, body)
        if body:
            d.update({'b': body})
        d.update({'e': encrypt})

        return d

    def _recv(self):
        data = self.req_socket.recv_json()
        log.debug("recv msg <- %s " % data)
        return data

    def _send(self, msg):
        log.debug("send msg->%s " % msg)
        self.req_socket.send_json(msg)

    def _req(self, session, msg):
        try:
            self._send(self._build_request(session, msg, self.encrypt_mode))
            data = self._recv()
            if 'r' in data and data['r'] == 0:
                body = data['b']
                if self.encrypt_mode:
                    body = self._decode(session, data['b'])

                if 'errcode' in body and body['errcode'] != 0:           # 第一层和第二层协议混在一起.
                    raise zrpcException(-2, body['errmsg'])

                return body

            if 'r' in data and data['r'] == -1002:
                    domain = self.users.keys()[0]
                    username = self.users[domain].keys()[0]
                    password = self.users[domain][username]
                    # 如果发现是需要认证的,则先认证，再重复发请求.
                    self.auth(domain, username, password)
                    return self._req(session, msg)

            else:
                raise zrpcException(-2, data['m'])

        except zmq.ZMQError, ex:
            log.exception(ex)
            thread.start_new_thread(self.init_sock, ())
            raise zrpcException(-1, str(ex))

        except zmq.error.Again, ex:
            log.exception(ex)
            thread.start_new_thread(self.init_sock, ())
            raise zrpcException(-1, str(ex))

    def _decode(self, session, body):
        try:
            result= self.user_session_pair[session][1].decrypt(body)
            return jsonapi.loads(result)
        except Exception, ex:
            raise zrpcException(-3, "Decrypt Error(%)" % ex.message)

    def _encode(self, session, body):
        try:
                # print 'try to encode', body, self.user_session_pair[session][1]
                return self.user_session_pair[session][1].encrypt(jsonapi.dumps(body))
        except Exception, ex:
            traceback.print_exc(file=sys.stdout)
            raise zrpcException(-3, "Encrypt Error(%s)" % ex.message)


class relayObject:
    def __init__(self, rpc, db,  session, model, context):
        self.rpc = rpc
        self.db = db
        self.session = session
        self.model = model
        self.context = context

    def __getattr__(self, name):
        msg = {'db': self.db, 'model': self.model, 'method': name}

        def func(*args, **kwargs):
            msg['params'] = args
            if 'context' not in kwargs:
                kwargs['context'] = self.context

            msg['kwargs'] = kwargs
            msg['context'] = kwargs.pop('context')
            return self.rpc.req(self.session, msg)['result']

        return func


class zServer(zrpcClient):
    def __init__(self, target="tcp://127.0.0.1:8100", security=True, read_timeout=5000, write_timeout=5000):
        zrpcClient.__init__(self, target, encrypt_mode=security, read_timeout=read_timeout, write_timeout=write_timeout)
        self.servList = {}

    def get(self, db, username, password):
        if db not in self.servList:
            session = self.auth(db, username, password)
            self.servList[db] = zService(self, db, session)

        return self.servList[db]


class zService(object):

    def __init__(self, server, db, session):
        self.server = server
        self.db = db
        self.session = session

        self.context = {}

    def get(self, model):
        return relayObject(self.server, self.db, self.session, model, self.context)


class RpcFileSession:
    def __init__(self, path):
        self.path = path
        log.debug("create rpc session store in %s"%self.path)

    def add_session(self, session, data):
        s_path = os.path.join(self.path, session)
        if not os.path.exists(s_path):
            f = open(s_path, "wb")
            f.write(pickle.dumps(data))
            f.close()
        return s_path

    def remove_session(self, session):
        s_path = os.path.join(self.path, session)
        if os.path.exists(s_path):
            os.remove(s_path)

    def get_session(self, session):
        s_path = os.path.join(self.path, session)
        if os.path.exists(s_path):
            f = open(s_path, "rb")
            data = pickle.loads(f.read())
            f.close()
            return data

    def save_session(self, session, data):
        pass

    def clean_session(self, session):
        """
            永不过期.
        """
        pass

class AESTransport:
    def __init__(self, aes_share_key):
        pass

    def send(self, socket, data):
        pass

    def recv(self, socket):
        pass

class zrpcServer(threading.Thread):
    """
        zrpc server:
            protocol: json
        request:
            s = sessionID.
            b = BODY
            [a] = Authentication Data ,  [domain\nusername\nmd5password]
            e= AES|RSA|none

        response:
            r = 0   errcode.  exists in response.
            m = errMsg.  exists when r!=0
            b = BODY
            e = AES/RSA/none
            [s]= SessionID.   send a response s.

        example first auth it to get sessison.
        请求: {s=0,b={},b={},a='username\nmd5 password',e:none}

    """
    def __init__(self, mode='node',  target="tcp://127.0.0.1:8009"):
        threading.Thread.__init__(self, name=target)
        self.read_timeout = 5000
        self.write_timeout = 5000
        self.target = target
        self.mode = mode
        self.rep_socket = self.create_rep_socket(self.target, mode)
        self.running = True

        self.sessions = {}
        self.session_store = self.create_session_store()
        self.init()

    def session_path(self):
        try:
            import pwd
            username = pwd.getpwuid(os.geteuid()).pw_name
        except ImportError:
            try:
                username = getpass.getuser()
            except Exception:
                username = "unknown"
        path = os.path.join(tempfile.gettempdir(), "zrpc-sessions-" + username)
        try:
            os.mkdir(path, 0700)
        except OSError as exc:
            if exc.errno == errno.EEXIST:
            # directory exists: ensure it has the correct permissions
            # this will fail if the directory is not owned by the current user
                os.chmod(path, 0700)
            else:
                raise
        return path

    def create_session_store(self):
        path = self.session_path()
        print 'session store in ', path
        return RpcFileSession(path)

    def init(self):
        pass

    def create_rep_socket(self, target="tcp://127.0.0.1:8009", mode='node'):
        context = zmq.Context()
        rep_socket = context.socket(zmq.REP)
        # rep_socket.setsockopt(zmq.RCVTIMEO, self.read_timeout)  # 5秒接收超时.
        rep_socket.setsockopt(zmq.SNDTIMEO, self.write_timeout)   # 5秒发送超时
        if mode == 'node':
            rep_socket.connect(target)

        elif mode == 'master':
            rep_socket.bind(target)

        log.info("pid[%s] create REP socket with (mode=%s) on target %s ok!" % (os.getpid(),
                                                                                            mode,
                                                                                            target))

        return rep_socket

    def run(self):
        while self.running:
            data = self.rep_socket.recv_json()
            # log.debug("recv zrpc request from pid[%s] <--%s" % (os.getpid(), data))
            ret = {}
            session = False
            body  = {}
            try:
                auth, session, body = self._pre_process(data)
                # log.debug("recv from session>%s body->%s" % (session, body))
                if auth:
                    ret = self._ret_auth_ok(session)
                else:
                    if session and body:
                        auth_identify = self.sessions[session][2]

                        ret_body = self.process(auth_identify, body)
                        # log.debug("resp to session->%s body ->%s"%(session, ret_body))
                        ret = self._build_response(session, ret_body)
                    else:
                        ret = self._ret_ok(session)
            except zrpcAuthFailed, f:
                    ret = self._ret_error(f.code, "exception:%s" % f.message)
                    traceback.print_exc(file=sys.stdout)

            except Exception, ex:
                    ret = self._ret_error(-1, "exception:%s" % ex.message)
                    traceback.print_exc(file=sys.stdout)
            finally:
                try:
                    # log.info("response zrpc from pid[%s] --->%s " % (os.getpid(), ret))
                    self.rep_socket.send_json(ret)
                except zmq.error.Again, ex:
                    log.error("send fail(%s),may socket is broken" % ex)

    def _add_session(self, auth_identify, domain, username, md5password, encrypt_mode):
        sec_key = md5("%s,%s,%s,%s" % (domain, username, md5password, uuid.uuid4())).hexdigest()
        sess = md5("@@aa%s,%s,%s,%s" % (domain, username, md5password, uuid.uuid4())).hexdigest()
        self.sessions[sess] = [encrypt_mode, AESCypher(secret=sec_key), auth_identify]
        self.session_store.add_session(sess, self.sessions[sess])

        return sess

    def _auth(self, data):
        if 'a' in data and data['a'] and 'e' in data:
            domain, username, md5password = data['a'].split("\n")
            auth_identify = self.authentication(domain, username, md5password)
            log.debug("auth->%s, %s, %s, result=%s"%(domain, username,md5password, auth_identify))

            if auth_identify and 'uid' in auth_identify and auth_identify['uid']:
                return self._add_session(auth_identify, domain, username, md5password, data['e'])
            else:
                raise zrpcAuthFailed(-1000, "Auth Failed")
        else:
            raise zrpcAuthFailed(-1002, "Auth Failed")

    def _get_session_cliper(self, s):
        if s in self.sessions:
            return self.sessions[s][1]

    def _get_session_encrypt_mode(self, s):
        if s in self.sessions:
            return self.sessions[s][0]

    def _check_session(self, s):
        if s in self.sessions:
            return True

        fs = self.session_store.get_session(s)
        if fs:
            self.sessions[s] = fs    # 提取出来并保存.
            return True

        return False

    def _pre_process(self, data):
        session = False
        auth = False
        if 's' in data and data['s']:
            if self._check_session(data['s']):
                session = data['s']
            else:
                session = self._auth(data)
                auth = True
        else:
            session = self._auth(data)
            auth = True

        if 'b' in data:
            if 'e' in data and data['e']:
                return auth, session, self._decode(data['b'], session)
            else:
                return auth, session, data['b']
        else:
            return auth, session, False

        return None,None, None

    def _decode(self, data, session):
        if not self._get_session_encrypt_mode(session):
            return data

        cypher = self._get_session_cliper(session)

        try:
            #print 'try to decode data', data, cypher
            result = cypher.decrypt(data)
            #print 'decode data', result
            return jsonapi.loads(result)

        except Exception, ex:
            raise zrpcException(-10003, "Decrypt Error(%s)"%str(ex.message))

    def _encode(self, data, session):
        if not self._get_session_encrypt_mode(session):
            return data

        cypher = self._get_session_cliper(session)
        if not cypher:
            return data

        try:
            return cypher.encrypt(jsonapi.dumps(data))
        except Exception, ex:
            raise zrpcException(-10003, "Enecrypt Error(%s)" % str(ex.message))

    def process(self, auth_identify, data):
        return self._ret_error(-1, "not implements")

    def authentication(self, domain, username, md5pass):
        return False

    def _build_response(self, session, body):
        if self._get_session_encrypt_mode(session):
            body = self._encode(body, session)

        d = {'e': self._get_session_encrypt_mode(session)}
        if session:
            d.update({'s': session})
        if body:
            d.update({'b': body})
        d.update({'r': 0, 'm': False})
        return d

    def _ret_auth_ok(self, session):
        d = {'r': 0, 'e': self._get_session_encrypt_mode(session), 's': session}
        cypher = self._get_session_cliper(session)
        if cypher:
            d.update({'a': cypher.secret})

        return d

    def _ret_ok(self, session):

        return d

    def _ret_error(self, code, msg):
        d = {}
        d.update({'r': code, 'm': msg})
        return d
















