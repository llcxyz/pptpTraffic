# coding:utf-8
#
#   uwsgi rpc 方法将应用内部变更消息发布出去.
#
#
#
__author__ = 'aron'
import zmq
import logging
log = logging.getLogger("proxy")
import os
import threading
from zmq.utils.monitor import recv_monitor_message

EVENT_MAP = {}
#print("Event names:")
for name in dir(zmq):
    if name.startswith('EVENT_'):
        value = getattr(zmq, name)
        #print("%21s : %4i" % (name, value))
        EVENT_MAP[value] = name


def event_monitor(monitor):
    while monitor.poll():
        evt = recv_monitor_message(monitor)
        evt.update({'description': EVENT_MAP[evt['event']]})
        print("Event: {}".format(evt))
        if evt['event'] == zmq.EVENT_MONITOR_STOPPED:
            break
    monitor.close()
    print()
    print("event monitor thread done!")


def proxy_route_dealer(r_port, d_port):
    context = zmq.Context()
    socket_route = context.socket(zmq.ROUTER)

    route_address = r_port
    socket_route.bind(route_address)
    log.info("pid[%s] create Router socket bind on:%s ok!" % (os.getpid(), route_address))
    # monitor = socket_route.get_monitor_socket()
    #
    # t = threading.Thread(target=event_monitor, args=(monitor,))
    # t.start()

    socket_dealer = context.socket(zmq.DEALER)
    dealer_address = d_port
    socket_dealer.bind(dealer_address)
    log.info("pid[%s] create Dealer socket bind on:%s ok!" % (os.getpid(), dealer_address))
    log.info("pid[%s] proxyRPC %s <--> %s start" % (os.getpid(), socket_route, socket_dealer))
    zmq.proxy(socket_route, socket_dealer)
    log.info("pid[%s] proxyRPC %s <--> %s done." % (os.getpid(), socket_route, socket_dealer))


def proxy_xsub_xpub(xsub, xpub):
    """
        将内部多个works内的publisher到同一个publisher.
    """
    context = zmq.Context()
    socket_xsub = context.socket(zmq.XSUB)
    xsub_address = xsub
    socket_xsub.set_hwm(50000)
    socket_xsub.bind(xsub_address)
    log.info("pid[%s] create XSUB socket bind on:%s ok!" % (os.getpid(), xsub_address))

    socket_xpub = context.socket(zmq.XPUB)
    xpub_address = xpub
    socket_xpub.set_hwm(50000)
    socket_xpub.bind(xpub_address)
    log.info("pid[%s] create XPUB socket bind on:%s ok!" % (os.getpid(), xpub_address))
    log.info("pid[%s] proxyPubSub %s <--> %s start " % (os.getpid(), socket_xsub, socket_xpub))
    zmq.proxy(socket_xsub, socket_xpub)
    log.info("pid[%s] proxyPubSub %s <--> %s done." % (os.getpid(), socket_xsub, socket_xpub))





