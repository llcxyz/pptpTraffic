# coding:utf-8
import zmq
__author__ = 'Aron'
import logging
import os
from openerp.osv import osv, fields

log = logging.getLogger("ws_msg_bridge")

class ws_msg_req(osv.TransientModel):
    _name = "ws.msg.req"
    push_socket = False
    _columns = {

    }

    def __init__(self, pool, cr):
        super(ws_msg_pusher, self).__init__(pool, cr)
        self.push_socket = self.create_req_socket()
        self.push({'type': 'init', 'pid': os.getpid(), 'data': 'init ok'})

    def create_req_socket(self, target="tcp://127.0.0.1:8100"):
        context = zmq.Context()
        push_socket = context.socket(zmq.REQ)
        push_socket.connect(target)
        log.info("pid[%s] create push socket to target %s ok!" %(os.getpid(), target))
        return push_socket

    def req(self, msg):
        self.push_socket.send_json(msg)





